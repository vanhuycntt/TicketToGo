package main

import (
	"context"
	"fmt"
	"log"
	reserve_seat_func "reserve-seat-func"
)
type Seat struct {
	ID int32  `firestore:"id,omitempty"`
	Name string  `firestore:"name,omitempty"`
	Status string  `firestore:"status,omitempty"`
	Price string  `firestore:"price,omitempty"`
}
func main() {
	ctx := context.Background()
	client, err := reserve_seat_func.AppFirebase.Firestore(ctx)
	if err != nil {
		log.Fatalf("Cannot create client: %v", err)
	}
	defer client.Close()
	dcIter,_ := client.Collection("ticketTypes").Doc("1").Collection("seats").Doc("1").Get(ctx)
	var seat Seat
	err = dcIter.DataTo(&seat)
	if err != nil{
		fmt.Println(err.Error())
	}
	fmt.Printf("Document data: %#v\n", seat)

}
