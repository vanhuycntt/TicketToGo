#!/bin/bash
sudo mkdir -p /etc/systemd/system/docker.service.d
sudo cat > /etc/systemd/system/docker.service.d/http-proxy.conf << EOF
[Service]
Environment="HTTP_PROXY=http://proxytc.vingroup.net:9090"
Environment="HTTPS_PROXY=http://proxytc.vingroup.net:9090"
EOF
sudo systemctl daemon-reload
sudo service docker restart